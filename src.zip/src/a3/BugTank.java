/*********************************************************************
 * BugTank.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/2/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.rendersystem.Renderable.*;
import ray.rage.scene.*;

public class BugTank implements ICollidable {

	private SceneManager sm;
	private Entity bugTankE;
	private SceneNode bugTankN;
	private String myName;
	private String cur_State; //WALK, ATTACK, DEATH
	private ICollidable blocker = null;
	private boolean blocked = false;
	private BugTankController bug_AI;
	private boolean markedfordeath = false;
	private boolean fromserverflag = false;
	private boolean hurtflag = false;
	private float health;
	private float x_offset = 2.0f,
			  	  y_offset = 3.0f,
			  	  z_offset = 2.0f;
	
	public BugTank(SceneManager sceneman, String name) throws IOException {
		sm = sceneman;
		health = 40.0f;
		myName = name;
		cur_State = "WALK";
		
		bugTankE = sm.createEntity(name, "BugTank.obj");
		bugTankE.setPrimitive(Primitive.TRIANGLES);
		
		bugTankN = sm.getSceneNode("monstersGroupNode").createChildSceneNode(bugTankE.getName() + "Node");
		bugTankN.attachObject(bugTankE);
	}
	
	public SceneNode getSceneNode() { return bugTankN; }
	
	public void handleCollision(ICollidable o) {
		if(o instanceof Pillar ||
		   o instanceof ArmorAnt ||
		   o instanceof BugTank ||
		   o instanceof Player) {
			this.setBlocker(o);
			blocked = true;
			cur_State = "WALK";
		}
		else if(o instanceof PowerSource) {
			this.setBlocker(o);
			blocked = true;
			cur_State = "ATTACK";
		}
		else if(o instanceof Bullet) {
			health -= 10.0f;
			if(health <= 0.0f) {
				cur_State = "DEATH";
				//bug_AI.removeAllNodes();
				markedfordeath = true;
			}
			else {
				hurtflag = true;
			}
		}
	}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public void setController(BugTankController btc) { bug_AI = btc; }
	public BugTankController getController() { return bug_AI; }
	
	public void setHealth(float v) { health = v; }
	public float getHealth() { return health; }
	
	public String getMyName() { return myName; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
	
	public void setHurtFlag(boolean value) { hurtflag = value; }
	public boolean isHurt() { return hurtflag; }
	
	public void setState(String value) { cur_State = value; }
	public String getState() { return cur_State; }
	
	public boolean isBlocked() { return blocked; }
	public void setBlocked(boolean value) { blocked = value; }
	
	public void setFromServer(boolean value) { fromserverflag = value; }
	public boolean isFromServer() { return fromserverflag; }
	
	public ICollidable getBlocker() { return blocker; }
	public void setBlocker(ICollidable b) { blocker = b; }
}
