/*********************************************************************
 * ICollidable.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/2/2019
 ********************************************************************/
package a3;

import ray.rage.scene.*;

public interface ICollidable {

	public abstract SceneNode getSceneNode();
	public abstract void handleCollision(ICollidable o);
	
	public abstract float getOffsetX();
	public abstract float getOffsetY();
	public abstract float getOffsetZ();
	
	public String getMyName();
	
	public void setMarkDeath(boolean value);
	public boolean isMarkedDeath();
}
