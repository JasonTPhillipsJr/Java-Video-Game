/*********************************************************************
 * Bullet.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/12/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.rendersystem.Renderable.*;
import ray.rage.scene.*;

public class Bullet implements ICollidable {

	private SceneManager sm;
	private Entity bulletE;
	private SceneNode bulletN;
	private BulletController bullet_AI;
	private String myName;
	private boolean markedfordeath = false;
	private float x_offset = 0.5f,
				  y_offset = 0.5f,
				  z_offset = 0.5f;
	
	public Bullet(SceneManager sceneman, String name) throws IOException {
		sm = sceneman;
		myName = name;
		bulletE = sm.createEntity(name, "Bullet.obj");
		bulletE.setPrimitive(Primitive.TRIANGLES);
		
		bulletN = sm.getRootSceneNode().createChildSceneNode(bulletE.getName() + "Node");
		bulletN.attachObject(bulletE);
	}
	
	public SceneNode getSceneNode() { return bulletN; }
	
	public void handleCollision(ICollidable o) {
		if(o instanceof Player ||
		   o instanceof BugTank ||
		   o instanceof ArmorAnt ||
		   o instanceof Pillar ||
		   o instanceof PowerSource ||
		   o instanceof Tower) {
			markedfordeath = true;
		}
	}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public String getMyName() { return myName; }
	
	public void setController(BulletController bc) { bullet_AI = bc; }
	public BulletController getController() { return bullet_AI; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
}
