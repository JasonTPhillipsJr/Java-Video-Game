/*********************************************************************
 * Pillar.java
 * Author: Jason Phillips & Andrew Wright
 * Created: 5/11/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.rendersystem.Renderable.*;
import ray.rage.scene.*;

public class Pillar implements ICollidable {

	private SceneManager sm;
	private Entity pillarE;
	private SceneNode pillarN;
	private String myName;
	private boolean markedfordeath = false;
	private float x_offset = 4.0f,
				  y_offset = 10.0f,
				  z_offset = 4.0f;
	
	public Pillar(SceneManager sceneman, String name) throws IOException {
		sm = sceneman;
		myName = name;
		pillarE = sm.createEntity(name, "Pillar.obj");
		pillarE.setPrimitive(Primitive.TRIANGLES);
		
		pillarN = sm.getRootSceneNode().createChildSceneNode(pillarE.getName() + "Node");
		pillarN.attachObject(pillarE);
	}
	
	public SceneNode getSceneNode() { return pillarN; }
	
	public void handleCollision(ICollidable o) {}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public String getMyName() { return myName; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
}
