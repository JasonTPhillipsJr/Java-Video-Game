/*********************************************************************
 * PowerSource.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/11/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.rendersystem.Renderable.*;
import ray.rage.scene.*;

public class PowerSource implements ICollidable {

	private SceneManager sm;
	private Entity powersourceE;
	private SceneNode powersourceN;
	private String myName;
	private String cur_State; //IDLE, DEATH
	private boolean fromserverflag = false;
	private boolean markedfordeath = false;
	private boolean hurtflag = false;
	private float health;
	private float x_offset = 5.0f,
				  y_offset = 8.0f,
				  z_offset = 5.0f;
	
	public PowerSource(SceneManager sceneman, String name) throws IOException {
		sm = sceneman;
		myName = name;
		cur_State = "IDLE";
		powersourceE = sm.createEntity(name, "PowerSource.obj");
		powersourceE.setPrimitive(Primitive.TRIANGLES);
		
		powersourceN = sm.getRootSceneNode().createChildSceneNode(powersourceE.getName() + "Node");
		powersourceN.attachObject(powersourceE);
		
		health = 1000.0f;
	}
	
	public SceneNode getSceneNode() { return powersourceN; }
	
	public void handleCollision(ICollidable o) {
		if(o instanceof Bullet) {
			health -= 10.0f;
			if(health <= 0.0f) {
				//Power source died...
				cur_State = "DEATH";
			}
			else {
				hurtflag = true;
			}
		}
	}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public void setHealth(float v) { health = v; }
	public float getHealth() { return health; }
	
	public String getMyName() { return myName; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
	
	public void setFromServer(boolean value) { fromserverflag = value; }
	public boolean isFromServer() { return fromserverflag; }
	
	public void setHurtFlag(boolean value) { hurtflag = value; }
	public boolean isHurt() { return hurtflag; }
	
	public void setState(String value) { cur_State = value; }
	public String getState() { return cur_State; }
}
