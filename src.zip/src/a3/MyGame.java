/*********************************************************************
 * MyGame.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 3/17/2019
 ********************************************************************/
package a3;

import myGameEngine.*;
import net.java.games.input.Controller;

import java.util.Iterator;
import java.util.Vector;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.nio.*;
import java.util.*;
import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.script.*;

import ray.rage.*;
import ray.rage.asset.material.Material;
import ray.rage.asset.texture.*;
import ray.rage.game.*;
import ray.rage.rendersystem.*;
import ray.rage.rendersystem.Renderable.*;
import ray.rage.scene.*;
import static ray.rage.scene.SkeletalEntity.EndType.*;
import ray.rage.scene.Camera.Frustum.*;
import ray.rage.scene.controllers.*;
import ray.rage.util.*;
import ray.rml.*;
import ray.rage.rendersystem.gl4.GL4RenderSystem;
import ray.rage.rendersystem.shader.GpuShaderProgram;
import ray.rage.rendersystem.states.*;
import ray.input.*;
import ray.input.action.*;

import ray.physics.*;

import ray.networking.IGameConnection.ProtocolType;

import ray.audio.*;
import com.jogamp.openal.ALFactory;
//import ray.rage.rendersystem.states.TextureState.WrapMode;


public class MyGame extends VariableFrameRateGame implements MouseListener, MouseMotionListener {

	Robot robot;
	Canvas canvas;
	RenderSystem rs;
	RenderWindow rw;
	float elapsTime = 0.0f;
	int elapsTimeSec, counter = 0;
	float posX, posY, posZ;
	String dispStr, dispStr2;
	static final String SKYBOX_NAME = "Skybox";
	boolean skyBoxVisible = true;
	
	private static String playerChoice;
	private SkeletalEntity playerSE;
	private SkeletalEntity ghostSE;
	
	private String playerState = "IDLE";
	private String oldState = "IDLE";
	private String ghostState = "IDLE";
	private String oldGhostState = "IDLE";
	
	protected SceneNode ghostN;
	private String serverAddress;		
	private int serverPort;
	private ProtocolType serverProtocol; 
	private ProtocolClient protClient;
	private boolean isClientConnected;
	private Vector<UUID>gameObjectsToRemove;
	private boolean set = false;
	
	private Player player = null;
	private PowerSource psource = null;
	
	private Light plight = null;
	
	private boolean enemiesAlive = false;
	
	private PhysicsEngine physEng;
	private boolean running = false;
	
	
	//Sound-related Variables
	private float movemt = 0.01f;

    IAudioManager audioMgr;
    Sound hereSound;
	
    
    
	ScriptEngineManager factory = new ScriptEngineManager();
    ScriptEngine jsEngine = factory.getEngineByName("js");
    File [] scriptFiles = new File[2];
    long [] scriptFilesLastMod = new long[2];
    
    volatile Vector<ICollidable> collidables = new Vector<ICollidable>(0);
	
	boolean doneflag1 = false; //Game Over, Players won.
	boolean doneflag2 = false; //Game Over, Bugs won.
	
	//Related to Mouse Movement
	float prevMouseX, prevMouseY, curMouseX, curMouseY;
	int centerX, centerY;
	boolean isRecentering;
	
	//Related to Input Control
	private InputManager im;
	private Action rotateLeftAction, rotateRightAction, rotateLeftRightGPAction;
	private Action pitchUpAction, pitchDownAction;
	private Action moveForwardAction, moveBackwardAction, moveBackForthGPAction;
	private Action playerIdle;
	private Action turnOnPSAction;
	private Action quitGameAction;
	
	
	//Change the arguments so that the class can accept the ip, port, and protocol arguments when compiling.
	public MyGame(String serverAddr, int sPort, String protocol)
	{
		super();
		this.serverAddress = serverAddr;
		this.serverPort = sPort;
		this.serverProtocol = ProtocolType.UDP;
		System.out.println("Welcome to the greatest game you will ever play");
		setupNetworking();
	}
	
	
/**************************************************************************************
 * (Jason Phillips Jr.)
 * This function basically creates a client on this pc.
 * The client will then continue setting up the connection to the server.(if it is on)
 *************************************************************************************/
	private void setupNetworking()
	{
		gameObjectsToRemove = new Vector<UUID>();
		isClientConnected = false;
		try
		{
			protClient = new ProtocolClient(InetAddress.getByName(serverAddress), serverPort, serverProtocol, this);
			System.out.println("You are now a client to the server");
			System.out.println(protClient.getID());
		}
		catch(UnknownHostException e)
		{
			e.printStackTrace();
			System.out.println("Server is not up and running");
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		if(protClient == null)
		{
			System.out.println("missing protocol host");
		}
		else
		{
			//ask client protocol to send initial join message
			//to server, with a unique identifier for this client
			protClient.sendJoinMessage();
		}
	}
	
	
/**************************************************************************************
 * (Jason Phillips Jr.)
 * This function is what allows the client to process packets every frame.
 *************************************************************************************/
	protected void processNetworking(float elapsTime)
	{
		//Process packets received by the client from the server
		
		if(protClient != null)
			protClient.processPackets();
		
		//remove ghost avatars for players who have left the game
        //Haven't implemented yet.
		Iterator<UUID>it = gameObjectsToRemove.iterator();
		while(it.hasNext()) 
		{
			// Potential problem here, if failure, check back in future tests.
			getEngine().getSceneManager().destroySceneNode(it.next().toString());
		}
		gameObjectsToRemove.clear();
	}
	
/************************************************
 * (Jason Phillips Jr.)
 * Simple setter for if connected.
 ***********************************************/
	public void setIsConnected(boolean b) 
	{
		isClientConnected = b;
		System.out.println("connected to server: " + b);
	}
	
	
/*******************************************************************************************************
 * (Jason Phillips Jr.)
 * Returns player position.
 * This is used to send player position to the server to tell other players where you are in the world
 *******************************************************************************************************/
	public Vector3 getPlayerPosition() 
	{
		SceneNode playerN = getEngine().getSceneManager().getSceneNode("playerNode");
		return playerN.getWorldPosition();	
	}
	
	
/*******************************************************************************************************
 * (Jason Phillips Jr.)
 * Returns player choice.
 *******************************************************************************************************/
	public String getCharacterSelect()
	{
		return playerChoice;
	}
	
	
	
/**************************************************************************************
 * (Jason Phillips Jr.)
 * character Select just uses the console for a quick select.
 *************************************************************************************/
	public static String characterSelect()
	{
		System.out.println("Please choose a character. Either Player 1 or Player 2");
		Scanner scan = new Scanner(System.in);
		int choice = 0;
		while(choice != 1 && choice !=2)
		{
			choice = scan.nextInt();
			if(choice != 1 && choice != 2)
				System.out.println("Please only choose 1 or 2");
		}
		if(choice ==1)
			return "Player1";
		else 
			return "Player2";
	}
	
	
	
	//Simple setter for the network code.
	public void setPlayerState(String state)
	{
		playerState = state;
	}
	
	//Simple getter for the network code.
	public String getPlayerState()
	{
		return playerState;
	}
	
	//This will set the player's animations depending on what their states are.
	//Their states should only change when we press a button or do a certain action.
	//Example, any time you move call this function with the new state included as a parameter.
	public void checkPlayerState(String newState, SkeletalEntity leMan)
	{
		
		if(!oldState.equals(newState))
		{
			if(newState.equals("IDLE"))
			{
				oldState = newState;
				doTheIdle(leMan);
				protClient.sendStateMessage(newState);
				
			}
			
			if(newState.equals("WALK"))
			{
				oldState = newState;
				doTheWalk(leMan);
				protClient.sendStateMessage(newState);
			}
			
			if(newState.equals("DEAD"))
			{
				doTheDead(leMan);
				oldState = newState;
				protClient.sendStateMessage(newState);
			}
		}
	}
	
	public void checkGhostState(String newState, SkeletalEntity leMan)
	{
		
		if(!oldGhostState.equals(newState))
		{
			if(newState.equals("IDLE"))
			{
				oldGhostState = newState;
				doTheIdle(leMan);
				
			}
			
			if(newState.equals("WALK"))
			{
				oldGhostState = newState;
				doTheWalk(leMan);
			}
			
			if(newState.equals("ATTACK"))
			{
				//Spawn a bullet at ghost node
				oldGhostState = newState;
			}
			
			if(newState.equals("DEAD"))
			{
				doTheDead(leMan);
				oldGhostState = newState;
			}
		}
	}
	
	
	
	public void updateGhostState(String state)
    {
        checkGhostState(state,ghostSE);
    }
		
		
	
/**************************************************************************************
 * (Jason Phillips Jr.)
 * This will add the other player into your world as a ghost avatar.
 *************************************************************************************/
	public void addGhostAvatarToGameWorld(GhostAvatar avatar)
	{
		SceneManager sm = getEngine().getSceneManager();
		if(set == false)
		{
			if(avatar != null)
			{
				try {
					System.out.println("the player choice was" + avatar.getPlayerChoice());
					
					if(avatar.getPlayerChoice().equals("Player1"))
					{
						ghostSE = (SkeletalEntity)sm.getEntity("ghostSE1");
						ghostN = sm.getRootSceneNode().createChildSceneNode("ghostNode");
						ghostN.attachObject(ghostSE);
						ghostSE.loadAnimation("walkAnimation", "Player1Walk.rka");
						ghostSE.loadAnimation("deathAnimation", "Player1Death.rka");
						set = true;
						//avatar.setPos(0,0,0); //if there is a failure in avatar location come back to this and fix the problem here <-------------------------------------------------------------------------------------------
					}
					
					else if(avatar.getPlayerChoice().equals("Player2"))
					{
						ghostSE = (SkeletalEntity)sm.getEntity("ghostSE2");
						ghostN = sm.getRootSceneNode().createChildSceneNode("ghostNode");
						ghostN.attachObject(ghostSE);
						ghostSE.loadAnimation("walkAnimation", "Player2Walk.rka");
						ghostSE.loadAnimation("deathAnimation", "Player2Death.rka");
						set = true;
					}
				}
				catch (IOException e)
				{
					System.out.println("Failure at add ghost avatar in myGame");
				}
			}
		}
		System.out.println(avatar.getPlayerState() + "is the ghost avatar's state");
	}
	
	
/**************************************************************************************
 * (Jason Phillips Jr.)
 * Whenever the client receives info about other players, this method is called.
 * It simply tells the client where the other players are in their worlds.
 *************************************************************************************/
	public void updateGhostPos(GhostAvatar avatar)
	{
		ghostN.setLocalPosition(avatar.getPos());
	}
	
/***************************************************
 * (Jason Phillips Jr.)
 * Rotates other players in client world.
 **************************************************/
	public void rotateGhostAvatar(float rotAmount)
    {
        Angle rot = Degreef.createFrom(rotAmount);
        ghostN.yaw(rot);
    }
	
/**************************************************************************************
 * (Jason Phillips Jr.)
 * Haven't used this method yet, but include for later implementation.
 *************************************************************************************/
	public void removeGhostAvatarFromGameWorld(GhostAvatar avatar)
	{ 
		if(avatar != null) gameObjectsToRemove.add((UUID) avatar.getID());
	}
	
	public boolean getSet() {
		return set;
	}
	
	
	
/**************************************************************************************
 * setEnemyInfo() Receives Enemy Information from the Server, to update Enemy Data
 *************************************************************************************/
	public void setEnemyInfo(String enemyName, float newHealth, String newState) {
		
		ICollidable o = getCollidableByName(enemyName);
		
		if(o != null) {
			if(o instanceof ArmorAnt) {
				ArmorAnt a = (ArmorAnt)o;
				a.setHealth(newHealth);
				if(newState.equals("DEATH")) {
					a.setState(newState);
					a.setMarkDeath(true);
					a.setFromServer(true);
				}
			}
			else if(o instanceof BugTank) {
				BugTank b = (BugTank)o;
				System.out.println("BugTank selected: " + b.getMyName());
				b.setHealth(newHealth);
				if(newState.equals("DEATH")) {
					b.setState(newState);
					b.setMarkDeath(true);
					b.setFromServer(true);
				}
			}
			else if(o instanceof PowerSource) {
				System.out.println("PowerSource selected: " + psource.getMyName());
				psource.setHealth(newHealth);
				if(newState.equals("DEATH")) {
					hereSound.stop();
					psource.setState(newState);
					psource.setFromServer(true);
					
					plight.setAmbient(new Color(0.0f, 0.0f, 0.0f));
					plight.setDiffuse(new Color(0.0f, 0.0f, 0.0f));
					plight.setSpecular(new Color(0.0f, 0.0f, 0.0f));
					
				}
				else if(newState.equals("ON")) {
					psource.setState(newState);
					hereSound.play();
					plight.setAmbient(new Color(0.0f, 0.0f, 0.0f));
					plight.setDiffuse(new Color(0.0f, 1.0f, 0.0f));
					plight.setSpecular(new Color(0.0f, 1.0f, 0.0f));
					
					
					SceneManager sm = getEngine().getSceneManager();
					
					//Create unique AI Node Controller for each ArmorAnt
					for(int i = 0; i < 5; i++) {
						ArmorAnt ant = (ArmorAnt)jsEngine.get("armorAnt" + (i+1));
						ant.setController(new ArmorAntController(this, ant));
						sm.addController(ant.getController());
						ant.getController().addNode(ant.getSceneNode());
					}
        
					//Create unique AI Node Controller for each BugTank
					for(int i = 0; i < 5; i++) {
						BugTank bug = (BugTank)jsEngine.get("bugTank" + (i+1));
						bug.setController(new BugTankController(this, bug));
						sm.addController(bug.getController());
						bug.getController().addNode(bug.getSceneNode());
					}
				}
			}
		}
	}
		
		
		
/***************************************************
 * main()
 **************************************************/
	public static void main(String[] args) {
		
		playerChoice = characterSelect();
		
        Game game = new MyGame(args[0], Integer.parseInt(args[1]), args[2]);
        try {
            game.startup();
            game.run();
        } catch (Exception e) {
            e.printStackTrace(System.err);
        } finally {
            game.shutdown();
            game.exit();
        }
    }
	
	
	
/***************************************************
 * setupWindow()
 **************************************************/
	@Override
	protected void setupWindow(RenderSystem rs, GraphicsEnvironment ge) {
		rs.createRenderWindow(new DisplayMode(1000, 700, 24, 60), false);
	}
	
	
/***************************************************
 * setupWindowViewports()
 **************************************************/
	@Override
	protected void setupWindowViewports(RenderWindow rw) {
		rw.addKeyListener(this);
		rw.addMouseListener(this);
		rw.addMouseMotionListener(this);
		rw.addMouseWheelListener(this);
	}
	
	
/***************************************************
 * setupCameras()
 **************************************************/
	@Override
    protected void setupCameras(SceneManager sm, RenderWindow rw) {
        SceneNode rootNode = sm.getRootSceneNode();
        RenderSystem rs = sm.getRenderSystem();
        
        //Create Player Camera
        Camera camera = sm.createCamera("MainCamera", Projection.PERSPECTIVE);
        rw.getViewport(0).setCamera(camera);

        SceneNode cameraNode = rootNode.createChildSceneNode(camera.getName() + "Node");
        cameraNode.attachObject(camera);
        camera.setMode('n');
        
        initMouseMode(rs,rw);
    }
	
	
/***************************************************
 * setupScene()
 **************************************************/
	@Override
    protected void setupScene(Engine eng, SceneManager sm) throws IOException {
	  
		/***************************************************
		 * Set up Physics Engine
		 **************************************************/
        initPhysicsSystem();
        
        
		/***************************************************
		 * Create Skybox
		 **************************************************/
		Configuration conf = eng.getConfiguration();
		TextureManager tm = eng.getTextureManager();
		tm.setBaseDirectoryPath(conf.valueOf("assets.skyboxes.path"));
		
		Texture front = tm.getAssetByPath("front.png");
		Texture back = tm.getAssetByPath("back.png");
		Texture left = tm.getAssetByPath("left.png");
		Texture right = tm.getAssetByPath("right.png");
		Texture top = tm.getAssetByPath("top.png");
		Texture bottom = tm.getAssetByPath("bottom.png");
		
		tm.setBaseDirectoryPath(conf.valueOf("assets.textures.path"));
		
		//cubemap textures initially upside-down, so let's flip them
		AffineTransform xform = new AffineTransform();
		xform.translate(0, front.getImage().getHeight());
		xform.scale(1d, -1d);
		
		front.transform(xform);
		back.transform(xform);
		left.transform(xform);
		right.transform(xform);
		top.transform(xform);
		bottom.transform(xform);
		
		SkyBox sb = sm.createSkyBox(SKYBOX_NAME);
		sb.setTexture(front, SkyBox.Face.FRONT);
		sb.setTexture(back, SkyBox.Face.BACK);
		sb.setTexture(left, SkyBox.Face.LEFT);
		sb.setTexture(right, SkyBox.Face.RIGHT);
		sb.setTexture(top, SkyBox.Face.TOP);
		sb.setTexture(bottom, SkyBox.Face.BOTTOM);
		sm.setActiveSkyBox(sb);
		
		
		/***************************************************
		 * Create Terrain
		 **************************************************/
		Tessellation terrain = sm.createTessellation("terrain", 9);
		
		terrain.setSubdivisions(32f);
		
		SceneNode terrainN = sm.getRootSceneNode().createChildSceneNode("terrainNode");
		terrainN.attachObject(terrain);
		terrainN.scale(1500, 5000, 1500);
		
		terrain.setHeightMap(eng, "island.png");
		terrain.setTexture(eng, "grass2.jpg");
		terrain.setNormalMap(eng, "islandNmap.png");
		
		createPhysicsObject(terrainN, "plane");
		
		
		/***************************************************
		 * Create Floor
		 **************************************************/
		ManualObject floor = makeFloor(eng,sm);
		floor.setPrimitive(Primitive.TRIANGLES);
		
		SceneNode floorN = sm.getRootSceneNode().createChildSceneNode("floorNode");
		floorN.attachObject(floor);
		
		floorN.scale(10000.0f, 1.0f, 10000.0f);
		floorN.setLocalPosition(0.0f, 5.0f, 0.0f);
		
		RenderSystem rs = sm.getRenderSystem(); 
		ZBufferState zstate = (ZBufferState) rs.createRenderState(RenderState.Type.ZBUFFER); 
		zstate.setTestEnabled(true); 
		floor.setRenderState(zstate);
		

		/***************************************************
		 * Set up Player
		 **************************************************/
		player = new Player(sm, "player", playerChoice);
        player.getSceneNode().setLocalPosition(20.0f, 85.0f, 0.0f);
        
        playerSE = player.getEntity();
        
        collidables.add(player);
        
        createPhysicsObject(player.getSceneNode(), "box");
        
        //Child node the represents the head of the player
        SceneNode plHeadN = player.getSceneNode().createChildSceneNode("playerHeadNode");
        plHeadN.setLocalPosition(0.0f, 4.0f, -0.6f);//0.1f
        plHeadN.yaw(Degreef.createFrom(180.0f));
        
        //Attach the camera to the head node, so we can see from the model's head, instead of its feet
        plHeadN.attachObject(sm.getCamera("MainCamera"));
        sm.getCamera("MainCamera").setMode('n');
        
        
        /***************************************************
		 * Set up Ghost Skeleton
		 **************************************************/
        //For the ghost
  		//We create these here so we don't get errors during network transfer
  		//Later in the code is where we tie them to a node.
  		SkeletalEntity ghostSE1 = sm.createSkeletalEntity("ghostSE1", "Player1.rkm", "Player1.rks");
  		Texture tex1 = sm.getTextureManager().getAssetByPath("Player.png");
  		TextureState tstate1 = (TextureState) sm.getRenderSystem().createRenderState(RenderState.Type.TEXTURE);
  		tstate1.setTexture(tex1);
  		ghostSE1.setRenderState(tstate1);
  		
  		SkeletalEntity ghostSE2 = sm.createSkeletalEntity("ghostSE2", "Player2.rkm", "Player2.rks");
  		Texture tex2 = sm.getTextureManager().getAssetByPath("Player2.png");
  		TextureState tstate2 = (TextureState) sm.getRenderSystem().createRenderState(RenderState.Type.TEXTURE);
  		tstate2.setTexture(tex2);
  		ghostSE2.setRenderState(tstate2);
        
        
        /***************************************************
		 * Set up Tower
		 **************************************************/
        Pillar[] pillars = new Pillar[4];

        for(int i = 0; i < 4; i++) {
        	pillars[i] = new Pillar(sm, "pillar" + (i+1));
        	collidables.add(pillars[i]);
        	createPhysicsObject(pillars[i].getSceneNode(), "box");
        }
        
        pillars[0].getSceneNode().setLocalPosition(20.0f, 78.0f, 20.0f);
        pillars[1].getSceneNode().setLocalPosition(20.0f, 78.0f, -20.0f);
        pillars[2].getSceneNode().setLocalPosition(-20.0f, 78.0f, 20.0f);
        pillars[3].getSceneNode().setLocalPosition(-20.0f, 78.0f, -20.0f);
        
        Tower tower = new Tower(sm, "tower");
        tower.getSceneNode().setLocalPosition(0.0f, 94.0f, 0.0f);
        
        collidables.add(tower);
        
        
        /***************************************************
		 * Set up Power Source
		 **************************************************/
        PowerSource powsrc = new PowerSource(sm, "powersource");
        powsrc.getSceneNode().setLocalPosition(0.0f, 77.5f, 0.0f);
        
        collidables.add(powsrc);
        
        psource = powsrc;
        
        createPhysicsObject(powsrc.getSceneNode(), "box");

        
        /***************************************************
		 * Set up Lighting
		 **************************************************/
        sm.getAmbientLight().setIntensity(new Color(.9f, .9f, .9f));
		
		plight = sm.createLight("testLamp1", Light.Type.POINT);
		plight.setAmbient(new Color(0.0f, 0.0f, 0.0f));
        plight.setDiffuse(new Color(1.0f, 0.0f, 0.0f));
		plight.setSpecular(new Color(1.0f, 0.0f, 0.0f));
        plight.setRange(200.0f);
		
		
		
		SceneNode plightNode = sm.getRootSceneNode().createChildSceneNode("plightNode");
        plightNode.attachObject(plight);
		plightNode.setLocalPosition(0.0f, 90.0f, 0.0f);
		//plightNode.pitch(Degreef.createFrom(90.0f));
        
        //Create Light Above Power Source
        Light psrcLight = sm.createLight("PowerSourceLight", Light.Type.POINT);
        psrcLight.setAmbient(new Color(0.0f, 0.0f, 0.0f));
        psrcLight.setDiffuse(new Color(0.0f, 0.0f, 0.0f));
        psrcLight.setSpecular(new Color(0.0f, 0.0f, 0.0f));
		//psrcLight.setConeCutoffAngle(Degreef.createFrom(20.0f));

		
        psrcLight.setRange(200.0f);
        
        SceneNode psrcLightN = sm.getRootSceneNode().createChildSceneNode("PowerSourceLightNode");
        psrcLightN.attachObject(psrcLight);
        psrcLightN.setLocalPosition(0.0f, 79.0f, 0.0f);
		//psrcLightN.pitch(Degreef.createFrom(90.0f));

        
        /***************************************************
		 * Set up Inputs
		 **************************************************/
		setupInputs();
        
		
        /***************************************************
		 * Set up Scripts
		 **************************************************/
        
        //Run Script to Spawn monsters
        scriptFiles[0] = new File("spawnMonsters.js");
        scriptFilesLastMod[0] = scriptFiles[0].lastModified();
        jsEngine.put("sm", sm);
        this.runScript(jsEngine, scriptFiles[0].getName());
        
        
        //Add ArmorAnts and BugTanks to Collidables List
        collidables.add((ICollidable)jsEngine.get("armorAnt1"));
        collidables.add((ICollidable)jsEngine.get("armorAnt2"));
        collidables.add((ICollidable)jsEngine.get("armorAnt3"));
        collidables.add((ICollidable)jsEngine.get("armorAnt4"));
        collidables.add((ICollidable)jsEngine.get("armorAnt5"));
        
        collidables.add((ICollidable)jsEngine.get("bugTank1"));
        collidables.add((ICollidable)jsEngine.get("bugTank2"));
        collidables.add((ICollidable)jsEngine.get("bugTank3"));
        collidables.add((ICollidable)jsEngine.get("bugTank4"));
        collidables.add((ICollidable)jsEngine.get("bugTank5"));
        
        
        //Create Physics Objects for ArmorAnts and BugTanks
        createPhysicsObject(sm.getSceneNode("armorAnt1Node"), "box");
        createPhysicsObject(sm.getSceneNode("armorAnt2Node"), "box");
        createPhysicsObject(sm.getSceneNode("armorAnt3Node"), "box");
        createPhysicsObject(sm.getSceneNode("armorAnt4Node"), "box");
        createPhysicsObject(sm.getSceneNode("armorAnt5Node"), "box");
        
        createPhysicsObject(sm.getSceneNode("bugTank1Node"), "box");
        createPhysicsObject(sm.getSceneNode("bugTank2Node"), "box");
        createPhysicsObject(sm.getSceneNode("bugTank3Node"), "box");
        createPhysicsObject(sm.getSceneNode("bugTank4Node"), "box");
        createPhysicsObject(sm.getSceneNode("bugTank5Node"), "box");
        
        /*
        //Create unique AI Node Controller for each ArmorAnt
        for(int i = 0; i < 5; i++) {
        	ArmorAnt ant = (ArmorAnt)jsEngine.get("armorAnt" + (i+1));
        	ant.setController(new ArmorAntController(this, ant));
        	sm.addController(ant.getController());
        	ant.getController().addNode(ant.getSceneNode());
        }
        
        //Create unique AI Node Controller for each BugTank
        for(int i = 0; i < 5; i++) {
        	BugTank bug = (BugTank)jsEngine.get("bugTank" + (i+1));
        	bug.setController(new BugTankController(this, bug));
        	sm.addController(bug.getController());
        	bug.getController().addNode(bug.getSceneNode());
        }
        */
        
        
        /***************************************************
		 * Start Physics Engine
		 **************************************************/
        running = true;
        
        
        /***************************************************
		 * Start Sound Setup
		 **************************************************/
        initAudio(sm);
    }
	
	
/***************************************************
 * update()
 **************************************************/
	@Override
    protected void update(Engine engine) {

		/***************************************************
		 * Build and set HUD
		 **************************************************/
		rs = (GL4RenderSystem) engine.getRenderSystem();
		elapsTime += engine.getElapsedTimeMillis();
		elapsTimeSec = Math.round(elapsTime/1000.0f);
		
		if(!psource.getState().equals("DEATH")) {
			dispStr = "PowerSource Health: " + psource.getHealth();
		}
		else if(!doneflag1) {
			doneflag2 = true;
		}

		
		if(doneflag1) {
			dispStr = "All enemies killed. Players Win!";
		}
		else if(doneflag2) {
			dispStr = "The PowerSource was destroyed. Players Lose!";
		}
		
		//Create HUD
		int x1 = rs.getRenderWindow().getViewport(0).getActualLeft();
		int y1 = rs.getRenderWindow().getViewport(0).getActualBottom();
		rs.setHUD(dispStr, x1 + 15, y1 + 15);
		

		
		/***************************************************
		 * Check for collisions between collidable objects
		 **************************************************/
		for(int i = 0; i < collidables.size(); i++) {			
			for(int j = i+1; j < collidables.size(); j++) {
				ICollidable c = collidables.elementAt(i);
				ICollidable other = collidables.elementAt(j);
				if(c != other && checkCollision(c, other)) {
					c.handleCollision(other);
					other.handleCollision(c);
				}
			}
		}
		
		
		/***************************************************
		 * Update Player Animations
		 **************************************************/
		SkeletalEntity playerSE = (SkeletalEntity)engine.getSceneManager().getEntity("player");
		playerSE.update();
		this.updateVerticalPosition("player", player.getHeightOffset());
		
		/***************************************************
		 * Update GhostAvatar Animations
		 **************************************************/
		SkeletalEntity ghostSE1 = (SkeletalEntity)engine.getSceneManager().getEntity("ghostSE1");
		ghostSE1.update();
		SkeletalEntity ghostSE2 = (SkeletalEntity)engine.getSceneManager().getEntity("ghostSE2");
		ghostSE2.update();
		
		
		/***************************************************
		 * Update each ArmorAnt's Animations
		 **************************************************/
		for(int i = 0; i < 5; i++) {
			//Update ArmorAnt Walk Animation
			SkeletalEntity armorAntSE = (SkeletalEntity)engine.getSceneManager().getEntity("armorAnt" + (i+1));
			if(armorAntSE.isAttached()) {
				armorAntSE.update();
				this.updateVerticalPosition("armorAnt" + (i+1), 2.0f);
			}
		}
	
		
		/***************************************************
		 * If Enemy loses health, send that info to the server
		 **************************************************/
		Iterator<ICollidable> i1 = collidables.iterator();
		ICollidable o1 = null;
		
		while(i1.hasNext()) {
			o1 = (ICollidable)i1.next();
			if(o1 instanceof ArmorAnt) {
				ArmorAnt a = (ArmorAnt)o1;
				if(a.isHurt()) {
					// Send this info to server: a.getMyName(), a.getHealth(), "ALIVE"
					protClient.sendBugInfo(a.getMyName(), a.getHealth(), "ALIVE");
					a.setHurtFlag(false);
				}
			}
			else if(o1 instanceof BugTank) {
				BugTank b = (BugTank)o1;
				if(b.isHurt()) {
					// Send this info to server: b.getMyName(), b.getHealth(), "ALIVE"
					protClient.sendBugInfo(b.getMyName(), b.getHealth(), "ALIVE");
					b.setHurtFlag(false);
				}
			}
		}
		
		
		/***************************************************
		 * If PowerSource loses health, send that info to the server
		 **************************************************/
		if(psource.isHurt()) {
			protClient.sendBugInfo(psource.getMyName(), psource.getHealth(), "ALIVE");
		}
		psource.setHurtFlag(false);
		
		
		/***************************************************
		 * If PowerSource dies, send that info to the server
		 **************************************************/
		if(psource.getState().equals("DEATH") && !psource.isFromServer()) {
			protClient.sendBugInfo(psource.getMyName(), psource.getHealth(), "DEATH");
			plight.setAmbient(new Color(0.0f, 0.0f, 0.0f));
			plight.setDiffuse(new Color(0.0f, 0.0f, 0.0f));
			plight.setSpecular(new Color(0.0f, 0.0f, 0.0f));
			hereSound.stop();
		}
		
		
		/***************************************************
		 * Deleting SceneNodes marked for death
		 **************************************************/
		 try {
			Iterator<ICollidable> i2 = collidables.iterator();
			ICollidable o2 = null;
			
			while(i2.hasNext()) {
				o2 = (ICollidable)i2.next();
				if(o2.isMarkedDeath()) {
					if(o2 instanceof ArmorAnt) {
						ArmorAnt a = (ArmorAnt)o2;
						if(!a.isFromServer()) {
							
							//Send this info to server: a.getMyName(), a.getHealth(), "DEATH"
							protClient.sendBugInfo(a.getMyName(), a.getHealth(), a.getState());
						}
						a.setFromServer(false);
					}
					else if(o2 instanceof BugTank) {
						BugTank b = (BugTank)o2;
						if(!b.isFromServer()) {
							//Send this info to server: b.getMyName(), b.getHealth(), "DEATH"
							protClient.sendBugInfo(b.getMyName(), b.getHealth(), b.getState());
						}
						b.setFromServer(false);
					}
					
					SceneNode sn = o2.getSceneNode();
					sn.detachAllChildren();
					engine.getSceneManager().destroySceneNode(sn);
					i2.remove();
				}
			}
		 } catch (java.util.ConcurrentModificationException ecme) {
			 System.out.println("ConcurrentModificationException happened.");
		 }
		
		
		/***************************************************
		 * Check For Living Enemies
		 **************************************************/
		Iterator<ICollidable> i3 = collidables.iterator();
		ICollidable o3 = null;
		
		while(i3.hasNext()) {
			o3 = (ICollidable)i3.next();
			if(o3 instanceof ArmorAnt ||
			   o3 instanceof BugTank) {
				enemiesAlive = true;
				break;
			}
		}
		
		if(!enemiesAlive && !doneflag2) {
			doneflag1 = true;
		}
		
		
		/***************************************************
		 * Update Physics Engine
		 **************************************************/
		 try {
			if(running) {
				Matrix4 mat;
				physEng.update(elapsTime);
				
				for(SceneNode s : engine.getSceneManager().getSceneNodes()) {
					if(s.getPhysicsObject() != null) {
						
						Tessellation terrain = (Tessellation)engine.getSceneManager()
								.getSceneNode("terrainNode").getAttachedObject("terrain");
						Vector3 sPos = s.getWorldPosition();
						mat = Matrix4f.createFrom(toFloatArray(s.getPhysicsObject().getTransform()));
						
						if(mat.value(1,3) > terrain.getWorldHeight(sPos.x(), sPos.z())) {
							s.setLocalPosition(mat.value(0,3), mat.value(1,3), mat.value(2,3));
						}
					}
				}
			}
		 } catch (java.util.ConcurrentModificationException ecme) {
			 System.out.println("ConcurrentModificationException happened.");
		 }
		
		
		/***************************************************
		 * Update Networking
		 **************************************************/
		processNetworking(elapsTime);

		
		/***************************************************
		 * Update Inputs
		 **************************************************/
		im.update(elapsTime);
		
	}
	
	

/***************************************************
 * runScript()
 **************************************************/
	private void runScript(ScriptEngine engine, String scriptFileName) {
		try {
			FileReader fileReader = new FileReader(scriptFileName);
			engine.eval(fileReader);
			fileReader.close();
		}
		catch (FileNotFoundException e1) {
			System.out.println(scriptFileName + " not found " + e1);
		}
		catch (IOException e2) {
			System.out.println("IO problem with " + scriptFileName + e2);
		}
		catch (ScriptException e3) {
			System.out.println("ScriptException in " + scriptFileName + e3);
		}
		catch (NullPointerException e4) {
			System.out.println ("Null ptr exception in " + scriptFileName + e4);
		}
	}
	
	

/***************************************************
 * initPhysicsSystem()
 **************************************************/
	private void initPhysicsSystem() {
		String engine = "ray.physics.JBullet.JBulletPhysicsEngine";
		float[] gravity = {0, -3f, 0};
		physEng = PhysicsEngineFactory.createPhysicsEngine(engine);
		physEng.initSystem();
		physEng.setGravity(gravity);
	}
	
	
	
/***************************************************
 * createPhysicsObject()
 **************************************************/
	private void createPhysicsObject(SceneNode sn, String type) {
		float mass = 1.0f;
		float up[] = {0,1,0};
		double[] temptf;
		
		temptf = toDoubleArray(sn.getLocalTransform().toFloatArray());
		
		PhysicsObject obj = null;
		
		switch (type) {
			case "sphere":
				obj = physEng.addSphereObject(physEng.nextUID(), mass, temptf, sn.getLocalScale().x());
				break;
			case "box":
				obj = physEng.addBoxObject(physEng.nextUID(), mass, temptf, sn.getLocalScale().toFloatArray());
				break;
			case "plane":
				obj = physEng.addStaticPlaneObject(physEng.nextUID(), temptf, up, 0.0f);
				break;
		}
		
		sn.setPhysicsObject(obj);
	}
	
	
/***************************************************
 * Conversion to/from Double/Float
 **************************************************/
	private float[] toFloatArray(double[] arr) {
		if (arr == null) return null;
		int n = arr.length;
		float[] ret = new float[n];
		for (int i = 0; i < n; i++) {
			ret[i] = (float)arr[i];
		}
		return ret;
	}
	
	
	private double[] toDoubleArray(float[] arr) {
		if (arr == null) return null;
		int n = arr.length;
		double[] ret = new double[n];
		for (int i = 0; i < n; i++) {
			ret[i] = (double)arr[i];
		}
		return ret;
	}
	
	
	
/***************************************************
 * initMouseMode()
 **************************************************/
	private void initMouseMode(RenderSystem r, RenderWindow w) {
		rw = w;
		rs = r;
		Viewport v = rw.getViewport(0);
		int left = rw.getLocationLeft();
		int top = rw.getLocationTop();
		int wi = v.getActualScissorWidth();
		int h = v.getActualScissorHeight();
		centerX = left + wi/2;
		centerY = top + h/2;
		isRecentering = false;
		
		try { robot = new Robot(); }
		catch(AWTException ex) {
			throw new RuntimeException("Couldn't create Robot!");
		}
		
		recenterMouse();
		prevMouseX = centerX;
		prevMouseY = centerY;
		
		//Create Invisible Cursor
		Cursor invisCursor = Toolkit.getDefaultToolkit().createCustomCursor(
				Toolkit.getDefaultToolkit().getImage(""), new Point(), "InvisibleCursor");
		canvas = rs.getCanvas();
		canvas.setCursor(invisCursor);
	}
	
	
/***************************************************
 * recenterMouse()
 **************************************************/
	private void recenterMouse() {
		Viewport v = rw.getViewport(0);
		int left = rw.getLocationLeft();
		int top = rw.getLocationTop();
		int wi = v.getActualScissorWidth();
		int h = v.getActualScissorHeight();
		centerX = left + wi/2;
		centerY = top + h/2;
		isRecentering = true;
		//Canvas canvas = rs.getCanvas();
		robot.mouseMove((int)centerX, (int)centerY);
	}
	
	
/***************************************************
 * mouseMoved()
 **************************************************/
	public void mouseMoved(MouseEvent e) {
		//check if event triggered by robot
		if(isRecentering &&
				centerX == e.getXOnScreen() && centerY == e.getYOnScreen()) {
			isRecentering = false;
		}
		else {
			curMouseX = e.getXOnScreen();
			curMouseY = e.getYOnScreen();
			
			float mouseDeltaX = prevMouseX - curMouseX;
			float mouseDeltaY = prevMouseY - curMouseY;
			
			if(mouseDeltaX > 5.0f) {
				rotateLeft("player");
			}
			else if(mouseDeltaX < -5.0f) {
				rotateRight("player");
			}
			
			if(mouseDeltaY > 7.0f) {
				pitchUp("player");
			}
			else if(mouseDeltaY < -7.0f) {
				pitchDown("player");
			}
			
			prevMouseX = curMouseX;
			prevMouseY = curMouseY;
			
			//Robot resets cursor to center
			recenterMouse();
			prevMouseX = centerX;
			prevMouseY = centerY;
		}
	}
	
	
	
/***************************************************
 * mouseClicked()
 **************************************************/
	public void mouseClicked(MouseEvent e) {
		if(e.getButton() == MouseEvent.BUTTON1) {
			
			this.setPlayerState("ATTACK");
			protClient.sendStateMessage("ATTACK");
			try {
				this.fireWeapon(this.getEngine().getSceneManager(), player);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			this.setPlayerState("IDLE");
			protClient.sendStateMessage("IDLE");
		}
		
	}

	
	
/***************************************************
 * setupInputs()
 **************************************************/
	protected void setupInputs() {
		im = new GenericInputManager();
		String kbName = null;// = im.getKeyboardName();
		
		ArrayList<Controller> controllers = im.getControllers();
		for (Controller c : controllers) 
		{
			if (c.getType() == Controller.Type.KEYBOARD)
			{

				kbName = c.getName();
				break;
				
			}
		}
			
		String gpName = im.getFirstGamepadName();
		
		if(gpName == null) {
			System.out.println("WARNING: No gamepad detected.\n");
		}
		
		//build Actions
		rotateLeftAction = new RotateLeftAction(this);
		rotateRightAction = new RotateRightAction(this);
		rotateLeftRightGPAction = new RotateLeftRightGPAction(this);
		pitchUpAction = new PitchUpAction(this);
		pitchDownAction = new PitchDownAction(this);
		moveForwardAction = new MoveForwardAction(this, player);
		moveBackwardAction = new MoveBackwardAction(this, player);
		moveBackForthGPAction = new MoveBackForthGPAction(this, player);
		quitGameAction = new QuitGameAction(this);
		playerIdle = new MoveForwardAction(this, player);
		turnOnPSAction = new TurnOnPSAction(this);
		
		
		/***********************************************************
		 * attach Rotate Left Action to keyboard input
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.A,
				rotateLeftAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		
		
		/***********************************************************
		 * attach Rotate Right Action to keyboard input
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.D,
				rotateRightAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		
		
		/***********************************************************
		 * attach Rotate Left/Right Action to gamepad input
		 **********************************************************/
		if(gpName != null) {
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Axis.X,
				rotateLeftRightGPAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		}
		
		
		/***********************************************************
		 * attach Pitch Up Action to keyboard inputs
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.UP,
				pitchUpAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		
		
		/***********************************************************
		 * attach Pitch Down Action to keyboard inputs
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.DOWN,
				pitchDownAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		
		
		/***********************************************************
		 * attach Move Forward Action to keyboard input
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.W,
				moveForwardAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		
		
		/***********************************************************
		 * attach Move Backward Action to keyboard input
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.S,
				moveBackwardAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		
		
		/***********************************************************
		 * attach Move Back/Forth Action to gamepad input
		 **********************************************************/
		if(gpName != null) {
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Axis.Y,
				moveBackForthGPAction, InputManager.INPUT_ACTION_TYPE.REPEAT_WHILE_DOWN);
		}
		
		
		/***********************************************************
		 * attach Turn On PowerSource Action to keyboard input
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.E,
				turnOnPSAction, InputManager.INPUT_ACTION_TYPE.ON_PRESS_AND_RELEASE);
		
		
		/***********************************************************
		 * attach Quit Game Action to keyboard and gamepad inputs
		 **********************************************************/
		im.associateAction(kbName, net.java.games.input.Component.Identifier.Key.ESCAPE,
				quitGameAction, InputManager.INPUT_ACTION_TYPE.ON_PRESS_AND_RELEASE);
		
		if(gpName != null) {
			im.associateAction(gpName, net.java.games.input.Component.Identifier.Button._3,
				quitGameAction, InputManager.INPUT_ACTION_TYPE.ON_PRESS_AND_RELEASE);
		}
	}
	
	
	
/***************************************************
 * rotateLeft()
 **************************************************/
	public void rotateLeft(String avatar) {
		Entity player = getEngine().getSceneManager().getEntity(avatar);
		
		Vector3 wUp = Vector3f.createFrom(0.0f, 1.0f, 0.0f);
		
		Angle rotAmt = Degreef.createFrom(110.0f * getEngine().getElapsedTimeMillis()/1000.0f);
		
		Vector3 u = player.getParentSceneNode().getLocalUpAxis();
		Vector3 f = player.getParentSceneNode().getLocalForwardAxis();
		Vector3 r = player.getParentSceneNode().getLocalRightAxis();
		
		Vector3 uUp = (u.rotate(rotAmt, wUp)).normalize();
		Vector3 fUp = (f.rotate(rotAmt, wUp)).normalize();
		Vector3 rUp = (r.rotate(rotAmt, wUp)).normalize();
		
		Matrix3 rot = Matrix3f.createFrom(rUp, uUp, fUp);
		player.getParentSceneNode().setLocalRotation(rot);
		
		protClient.sendRotMessage(110.0f * getEngine().getElapsedTimeMillis()/1000.0f);
	}
	
	
/***************************************************
 * rotateRight()
 **************************************************/
	public void rotateRight(String avatar) {
		Entity player = getEngine().getSceneManager().getEntity(avatar);
		
		Vector3 wUp = Vector3f.createFrom(0.0f, 1.0f, 0.0f);
		
		Angle rotAmt = Degreef.createFrom(-110.0f * getEngine().getElapsedTimeMillis()/1000.0f);
		
		Vector3 u = player.getParentSceneNode().getLocalUpAxis();
		Vector3 f = player.getParentSceneNode().getLocalForwardAxis();
		Vector3 r = player.getParentSceneNode().getLocalRightAxis();
		
		Vector3 uUp = (u.rotate(rotAmt, wUp)).normalize();
		Vector3 fUp = (f.rotate(rotAmt, wUp)).normalize();
		Vector3 rUp = (r.rotate(rotAmt, wUp)).normalize();
		
		Matrix3 rot = Matrix3f.createFrom(rUp, uUp, fUp);
		player.getParentSceneNode().setLocalRotation(rot);
		
		protClient.sendRotMessage(-110.0f * getEngine().getElapsedTimeMillis()/1000.0f);
	}
	
	
/***************************************************
 * pitchUp()
 **************************************************/
	public void pitchUp(String avatar) {
		Entity player = getEngine().getSceneManager().getEntity(avatar);

		Angle pitchAmt = Degreef.createFrom(140.0f * getEngine().getElapsedTimeMillis()/1000.0f);
		player.getParentNode().pitch(pitchAmt);
	}
	
	
/***************************************************
 * pitchDown()
 **************************************************/
	public void pitchDown(String avatar) {
		Entity player = getEngine().getSceneManager().getEntity(avatar);

		Angle pitchAmt = Degreef.createFrom(-140.0f * getEngine().getElapsedTimeMillis()/1000.0f);
		player.getParentNode().pitch(pitchAmt);
	}
	
	
/***************************************************
 * moveForward()
 **************************************************/
	public void moveForward(String avatar, Player p) {
		Entity player = getEngine().getSceneManager().getEntity(avatar);
		
		float moveAmt = -20.0f * (getEngine().getElapsedTimeMillis()/1000.0f);
		player.getParentNode().moveForward(moveAmt);
		
		if(p.isBlocked()) {
			boolean blocked = checkCollision(p, p.getBlocker());
			
			if(blocked) {
				player.getParentNode().moveForward(-moveAmt);
			}
			else {
				p.setBlocked(false);
				p.setBlocker(null);
			}
		}
		
		protClient.sendMoveMessage(player.getParentSceneNode().getWorldPosition());
	}
	
	
/***************************************************
 * moveBackward()
 **************************************************/
	public void moveBackward(String avatar, Player p) {
		Entity player = getEngine().getSceneManager().getEntity(avatar);
		
		float moveAmt = -20.0f * (getEngine().getElapsedTimeMillis()/1000.0f);
		player.getParentNode().moveBackward(moveAmt);
		
		if(p.isBlocked()) {
			boolean blocked = checkCollision(p, p.getBlocker());
			
			if(blocked) {
				player.getParentNode().moveBackward(-moveAmt);
			}
			else {
				p.setBlocked(false);
				p.setBlocker(null);
			}
		}
		
		protClient.sendMoveMessage(player.getParentSceneNode().getWorldPosition());
	}
	
	
	
/***************************************************
 * fireWeapon()
 **************************************************/
	public void fireWeapon(SceneManager sm, Player p) throws IOException {
		Bullet bullet = new Bullet(sm, "bullet" + (p.getBulletCount() + 1));
		p.setBulletCount(p.getBulletCount() + 1);
		
		collidables.add(bullet);

    	bullet.setController(new BulletController(this, bullet));
    	sm.addController(bullet.getController());
    	bullet.getController().addNode(bullet.getSceneNode());
		
		Vector3f pPo = (Vector3f)p.getSceneNode().getLocalPosition();
		Vector3f pFd = (Vector3f)p.getSceneNode().getLocalForwardAxis();
		Vector3f pP1 = (Vector3f)Vector3f.createFrom(-6.0f*pFd.x(), -6.0f*pFd.y(), -6.0f*pFd.z());
		Vector3f pP2 = (Vector3f)pPo.add((Vector3f)pP1);
		
		bullet.getSceneNode().setLocalPosition(pP2);
		bullet.getSceneNode().setLocalRotation(p.getSceneNode().getLocalRotation());
	}
	
	
	
/***************************************************
 * turnonPowerSource()
 **************************************************/
	public void turnOnPowerSource() {
		if(psource.getState().equals("IDLE")) {
			if(checkCollision(player, psource)) {
				psource.setState("ON");
				hereSound.play();
				protClient.sendBugInfo(psource.getMyName(), psource.getHealth(), psource.getState());
				plight.setAmbient(new Color(0.0f, 0.0f, 0.0f));
				plight.setDiffuse(new Color(0.0f, 1.0f, 0.0f));
				plight.setSpecular(new Color(0.0f, 1.0f, 0.0f));
				
				
				SceneManager sm = getEngine().getSceneManager();
				
				//Create unique AI Node Controller for each ArmorAnt
				for(int i = 0; i < 5; i++) {
					ArmorAnt ant = (ArmorAnt)jsEngine.get("armorAnt" + (i+1));
					ant.setController(new ArmorAntController(this, ant));
					sm.addController(ant.getController());
					ant.getController().addNode(ant.getSceneNode());
				}
        
				//Create unique AI Node Controller for each BugTank
				for(int i = 0; i < 5; i++) {
					BugTank bug = (BugTank)jsEngine.get("bugTank" + (i+1));
					bug.setController(new BugTankController(this, bug));
					sm.addController(bug.getController());
					bug.getController().addNode(bug.getSceneNode());
				}
			}
		}
	}
	
	
	
/***************************************************
 * updateVerticalPosition()
 **************************************************/
	public void updateVerticalPosition(String avatar, float offset) {
		Entity objE = getEngine().getSceneManager().getEntity(avatar);
		SceneNode objN = objE.getParentSceneNode();
		
		SceneNode terrainN = getEngine().getSceneManager().getSceneNode("terrainNode");
		
		Tessellation terrain = (Tessellation)terrainN.getAttachedObject("terrain");
		
		Vector3 worldAvatarPos = objN.getWorldPosition();
		Vector3 localAvatarPos = objN.getLocalPosition();
		
		Vector3 newAvatarPos = Vector3f.createFrom(
				localAvatarPos.x(),
				terrain.getWorldHeight(worldAvatarPos.x(), worldAvatarPos.z()) + offset,
				localAvatarPos.z()
				);
		
		//Only update SceneNode position if below the terrain
		if(localAvatarPos.y() < terrain.getWorldHeight(worldAvatarPos.x(), worldAvatarPos.z()) + offset) {
			objN.setLocalPosition(newAvatarPos);
		}
		
		//Update physics object attached to the SceneNode
		Matrix4 mat = Matrix4f.createFrom(objN.getLocalTransform().toFloatArray());
		objN.getPhysicsObject().setTransform(toDoubleArray(mat.toFloatArray()));
	}
	
	
	
/***************************************************
 * checkCollision()
 **************************************************/
	public boolean checkCollision(ICollidable c, ICollidable o) {
		float cx1 = c.getSceneNode().getLocalPosition().x() - c.getOffsetX(); //minX
		float cx2 = c.getSceneNode().getLocalPosition().x() + c.getOffsetX(); //maxX
		
		float cy1 = c.getSceneNode().getLocalPosition().y() - c.getOffsetY();
		float cy2 = c.getSceneNode().getLocalPosition().y() + c.getOffsetY();
		
		float cz1 = c.getSceneNode().getLocalPosition().z() - c.getOffsetZ();
		float cz2 = c.getSceneNode().getLocalPosition().z() + c.getOffsetZ();
		
		
		float ox1 = o.getSceneNode().getLocalPosition().x() - o.getOffsetX();
		float ox2 = o.getSceneNode().getLocalPosition().x() + o.getOffsetX();

		float oy1 = o.getSceneNode().getLocalPosition().y() - o.getOffsetY();
		float oy2 = o.getSceneNode().getLocalPosition().y() + o.getOffsetY();
		
		float oz1 = o.getSceneNode().getLocalPosition().z() - o.getOffsetZ();
		float oz2 = o.getSceneNode().getLocalPosition().z() + o.getOffsetZ();
		
		boolean xflag = false, yflag = false, zflag = false;
		
		if(cx1 <= ox2 && cx2 >= ox1) {
			xflag = true;
		}
		
		if(cy1 <= oy2 && cy2 >= oy1) {
			yflag = true;
		}
		
		if(cz1 <= oz2 && cz2 >= oz1) {
			zflag = true;
		}
		
		if(xflag && yflag && zflag) {
			return true;
		}
		
		return false;
	}
	
	
	
/***************************************************
 * getCollidableByName()
 **************************************************/
	public ICollidable getCollidableByName(String name) {
		Iterator<ICollidable> i = collidables.iterator();
		ICollidable o = null;
		
		while(i.hasNext()) {
			o = (ICollidable)i.next();
			if(o.getMyName().equals(name)) {
				return o; //Found the one we're looking for, return it
			}
		}
		
		return null; //Didn't find it, return null
	}
	
/***************************************************
 * Make the Floor
 **************************************************/
	protected ManualObject makeFloor (Engine eng, SceneManager sm) throws IOException {
		ManualObject floor = sm.createManualObject("Floor");
		ManualObjectSection floorSec = floor.createManualSection("FloorSection");
		floor.setGpuShaderProgram(sm.getRenderSystem().getGpuShaderProgram(GpuShaderProgram.Type.RENDERING));
		
		Material mat1 = sm.getMaterialManager().getAssetByPath("default.mtl");
		
		Texture tex = sm.getTextureManager().getAssetByPath("bright-blue.jpeg");
		TextureState tstate = (TextureState) sm.getRenderSystem().createRenderState(RenderState.Type.TEXTURE);
		tstate.setTexture(tex);
		floorSec.setRenderState(tstate);
		floorSec.setMaterial(mat1);
		
		float[] vertices = new float[] {
			1.0f,0.0f,1.0f,-1.0f,0.0f,-1.0f,-1.0f,0.0f,1.0f, //Lower Left
			1.0f,0.0f,1.0f,1.0f,0.0f,-1.0f,-1.0f,0.0f,-1.0f  //Upper Right
		};
		
		float[] normals = new float[] {
			0.0f,1.0f,0.0f,
			0.0f,1.0f,0.0f
		};
		
		float[] texcoords = new float[] {
			1.0f,0.0f,0.0f,1.0f,0.0f,0.0f,
			1.0f,0.0f,1.0f,1.0f,0.0f,1.0f
		};
		
		int[] indices = new int[] {0,1,2,3,4,5};
		
		FloatBuffer vertbuf = BufferUtil.directFloatBuffer(vertices);
		FloatBuffer normbuf = BufferUtil.directFloatBuffer(normals);
		FloatBuffer texbuf = BufferUtil.directFloatBuffer(texcoords);
		IntBuffer indexbuf = BufferUtil.directIntBuffer(indices);
		
		floorSec.setVertexBuffer(vertbuf);
		floorSec.setNormalsBuffer(normbuf);
		floorSec.setTextureCoordsBuffer(texbuf);
		floorSec.setIndexBuffer(indexbuf);
		
		floor.setDataSource(DataSource.INDEX_BUFFER);
		return floor;
	}
	
	
	
/***************************************************
 * doTheWalk() (Entity Walk Animation)
 **************************************************/
	public void doTheWalk(SkeletalEntity entity) {
		SkeletalEntity objSE = entity;
		objSE.stopAnimation();
		objSE.playAnimation("WalkAnimation", 0.6f, LOOP, 0);
	}
	
	
	
/***************************************************
 * doTheDead() (Entity Death Animation)
 **************************************************/
	public void doTheDead(SkeletalEntity entity) {
		SkeletalEntity objSE = entity;
		objSE.stopAnimation();
		objSE.playAnimation("DeathAnimation", 0.6f, PAUSE, 0);
	}
	
	
	
/***************************************************
 * doTheIdle() (Entity Idle Animation)
 **************************************************/
	public void doTheIdle(SkeletalEntity entity) {
		SkeletalEntity objSE = entity;
		objSE.stopAnimation();
	}
	
	
	
/***************************************************
 * armorAntAttack() (Armor Ant Attack Animation)
 **************************************************/
	public void armorAntAttack(SkeletalEntity entity) {
		SkeletalEntity objSE = entity;
		objSE.stopAnimation();
		objSE.playAnimation("AttackAnimation", 0.6f, LOOP, 0);
	}
	
	
	
/***************************************************
 * armorAntDeath() (Armor Ant Death Animation)
 **************************************************/
	public void armorAntDeath(SkeletalEntity entity) {
		SkeletalEntity objSE = entity;
		objSE.stopAnimation();
		objSE.playAnimation("DeathAnimation", 0.6f, PAUSE, 0);
	}
	
	

/***************************************************
 * initAudio()
 **************************************************/
	public void initAudio(SceneManager sm)
	{
		AudioResource resource1, resource2;
		audioMgr = AudioManagerFactory.createAudioManager(
				"ray.audio.joal.JOALAudioManager");
		if(!audioMgr.initialize())
		{
			System.out.println("Audio Manager failed to initialize!");
			return;
		}
		
		resource1 = audioMgr.createAudioResource("buzz.wav", AudioResourceType.AUDIO_SAMPLE);
		
		hereSound = new Sound(resource1, SoundType.SOUND_EFFECT, 100, true);
		
		hereSound.initialize(audioMgr);
		
		hereSound.setMaxDistance(20.0f);
		hereSound.setMinDistance(.5f);
		hereSound.setRollOff(5.0f);
	
		SceneNode psn = psource.getSceneNode();
		hereSound.setLocation(psn.getWorldPosition());
		
		setEarParameters(sm);
	}
	
	
	
/***************************************************
 * setEarParameters()
 **************************************************/
	public void setEarParameters(SceneManager sm)
	{
	
		Vector3 avDir = player.getSceneNode().getWorldForwardAxis();// We might need to switch this around.
		
		audioMgr.getEar().setLocation(player.getSceneNode().getWorldPosition());
		audioMgr.getEar().setOrientation(avDir,  Vector3f.createFrom(0.0f, 1.0f, 0.0f));
	}
}
