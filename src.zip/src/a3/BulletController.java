/*********************************************************************
 * BulletController.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/13/2019
 ********************************************************************/
package a3;

import ray.rage.scene.*;
import ray.rage.scene.controllers.*;
import ray.rml.Angle;
import ray.rml.Degreef;
import ray.rml.Vector3;
import ray.rml.Vector3f;

public class BulletController extends AbstractController {

	private MyGame game;
	private Bullet bullet;
	private float movAmt = 1.0f;
	private float cycleTime = 5000.0f; // default cycle time (5 seconds)
	private float totalTime = 0.0f;
	
	public BulletController(MyGame g, Bullet b) {
		game = g;
		bullet = b;
	}
	
	@Override
	protected void updateImpl(float elapsedTimeMillis) {
		totalTime += elapsedTimeMillis;
		
		if(totalTime > cycleTime) {
			bullet.setMarkDeath(true);
		}
		
		 for(Node n : super.controlledNodesList) {
			 n.moveForward(-movAmt);
			 
			 SceneNode terrainN = game.getEngine().getSceneManager().getSceneNode("terrainNode");
			 Tessellation terrain = (Tessellation)terrainN.getAttachedObject("terrain");
			 
			 Vector3 worldAvatarPos = bullet.getSceneNode().getWorldPosition();
			 Vector3 localAvatarPos = bullet.getSceneNode().getLocalPosition();
				
			//Only update SceneNode position if below the terrain
			if(localAvatarPos.y() < terrain.getWorldHeight(worldAvatarPos.x(), worldAvatarPos.z())) {
				bullet.setMarkDeath(true);
				
			}
		 }
	}
}
