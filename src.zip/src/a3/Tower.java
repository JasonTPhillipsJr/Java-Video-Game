/*********************************************************************
 * Tower.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/12/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.rendersystem.Renderable.*;
import ray.rage.scene.*;

public class Tower implements ICollidable {

	private SceneManager sm;
	private Entity towerE;
	private SceneNode towerN;
	private String myName;
	private boolean markedfordeath = false;
	private float x_offset = 25.0f,
				  y_offset = 0.0f,
				  z_offset = 25.0f;
	
	public Tower(SceneManager sceneman, String name) throws IOException {
		sm = sceneman;
		myName = name;
		towerE = sm.createEntity(name, "Tower.obj");
		towerE.setPrimitive(Primitive.TRIANGLES);
		
		towerN = sm.getRootSceneNode().createChildSceneNode(towerE.getName() + "Node");
		towerN.attachObject(towerE);
	}
	
	public SceneNode getSceneNode() { return towerN; }
	
	public void handleCollision(ICollidable o) {}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public String getMyName() { return myName; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
}
