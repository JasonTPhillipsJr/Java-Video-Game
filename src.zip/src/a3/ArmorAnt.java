/*********************************************************************
 * ArmorAnt.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/2/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.asset.texture.Texture;
import ray.rage.rendersystem.Renderable.*;
import ray.rage.rendersystem.states.RenderState;
import ray.rage.rendersystem.states.TextureState;
import ray.rage.scene.*;

public class ArmorAnt implements ICollidable {
	
	private SceneManager sm;
	private SkeletalEntity armorAntSE;
	private SceneNode armorAntN;
	private String myName;
	private String cur_State; //WALK, ATTACK, DEATH
	private ICollidable blocker = null;
	private boolean blocked = false;
	private ArmorAntController ant_AI;
	private boolean markedfordeath = false;
	private boolean fromserverflag = false;
	private boolean hurtflag = false;
	private float health;
	private float height_offset = 2.0f;
	private float x_offset = 2.0f,
			  	  y_offset = 4.0f,
			  	  z_offset = 2.0f;
	
	public ArmorAnt(SceneManager sceneman, String name) throws IOException {
		sm = sceneman;
		myName = name;
		health = 50.0f;
		cur_State = "WALK";
		
		armorAntSE = sm.createSkeletalEntity(name, "ArmorAnt.rkm", "ArmorAnt.rks");
		Texture tex = sm.getTextureManager().getAssetByPath("ArmorAnt.png");
		TextureState tstate = (TextureState)sm.getRenderSystem().createRenderState(RenderState.Type.TEXTURE);
		tstate.setTexture(tex);
		armorAntSE.setRenderState(tstate);
		
		armorAntN = sm.getSceneNode("monstersGroupNode").createChildSceneNode(armorAntSE.getName() + "Node");
		armorAntN.attachObject(armorAntSE);
		
		armorAntSE.loadAnimation("WalkAnimation", "ArmorAntWalk.rka");
		armorAntSE.loadAnimation("AttackAnimation", "ArmorAntAttack.rka");
		armorAntSE.loadAnimation("DeathAnimation", "ArmorAntDeath.rka");
	}
	
	public SceneNode getSceneNode() { return armorAntN; }
	
	public void handleCollision(ICollidable o) {
		if(o instanceof Pillar ||
		   o instanceof ArmorAnt) {
			this.setBlocker(o);
			blocked = true;
		}
		else if(o instanceof PowerSource ||
				o instanceof Player) {
			this.setBlocker(o);
			blocked = true;
			cur_State = "ATTACK";
		}
		else if(o instanceof BugTank) {
			this.setBlocker(o);
			blocked = true;
		}
		else if(o instanceof Bullet) {
			health -= 10.0f;
			if(health <= 0.0f) {
				cur_State = "DEATH";
				//ant_AI.removeAllNodes();
				markedfordeath = true;
			}
			else {
				hurtflag = true;
			}
		}
	}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public void setController(ArmorAntController aac) { ant_AI = aac; }
	public ArmorAntController getController() { return ant_AI; }
	
	public String getMyName() { return myName; }
	
	public boolean isBlocked() { return blocked; }
	public void setBlocked(boolean value) { blocked = value; }
	
	public ICollidable getBlocker() { return blocker; }
	public void setBlocker(ICollidable b) { blocker = b; }
	
	public float getHeightOffset() { return height_offset; }
	
	public void setState(String value) { cur_State = value; }
	public String getState() { return cur_State; }
	
	public void setHealth(float v) { health = v; }
	public float getHealth() { return health; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
	
	public void setFromServer(boolean value) { fromserverflag = value; }
	public boolean isFromServer() { return fromserverflag; }
	
	public void setHurtFlag(boolean value) { hurtflag = value; }
	public boolean isHurt() { return hurtflag; }
}
