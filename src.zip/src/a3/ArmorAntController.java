/*********************************************************************
 * ArmorAntController.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/13/2019
 ********************************************************************/
package a3;

import ray.rage.scene.*;
import ray.rage.scene.controllers.*;
import ray.rml.Angle;
import ray.rml.Degreef;
import ray.rml.Vector3f;

public class ArmorAntController extends AbstractController {

	private MyGame game;
	private ArmorAnt ant;
	private float movAmt = 0.1f;
	private Angle rotAmt = Degreef.createFrom(0.0f);
	private float cycleTime = 2000.0f; // default cycle time (2 seconds)
	private float totalTime = 0.0f;
	private float timer = 0.0f;
	
	public ArmorAntController(MyGame g, ArmorAnt a) {
		game = g;
		ant = a;
	}
	
	public void setTimer(float time) { totalTime = time; }
	
	@Override
	protected void updateImpl(float elapsedTimeMillis) {
		 totalTime += elapsedTimeMillis;
		 timer += elapsedTimeMillis;

		 if (totalTime > cycleTime) {
			 
			 if(ant.getState() == "WALK") {
				 for(Node n : super.controlledNodesList) {
					 SceneNode psourceN = game.getEngine().getSceneManager().getSceneNode("powersourceNode");
					 n.lookAt(psourceN);
					 game.doTheWalk((SkeletalEntity)game.getEngine().getSceneManager().getEntity(ant.getMyName()));
				 }
			 
				 //totalTime = 0.0f;
			 }
			 else if(ant.getState() == "ATTACK") {
				 for(Node n : super.controlledNodesList) {
					 SkeletalEntity sk = (SkeletalEntity)game.getEngine().getSceneManager().getEntity(ant.getMyName());
					 game.armorAntAttack(sk);
				 }
			 }
			 else if(ant.getState() == "DEATH") {
				 for(Node n : super.controlledNodesList) {
					 SkeletalEntity sk = (SkeletalEntity)game.getEngine().getSceneManager().getEntity(ant.getMyName());
					 sk.stopAnimation();
					 game.armorAntDeath(sk);
					 ant.setMarkDeath(true);
				 }
			 }
			 
			 totalTime = 0.0f;
		 }
		 
		 for(Node n : super.controlledNodesList) {
			 
			 if(ant.getState() == "WALK") {
				 n.moveForward(movAmt);
				 
				 if(ant.isBlocked()) {
					boolean blocked = game.checkCollision(ant, ant.getBlocker());
					
					if(blocked) {
						n.moveForward(-movAmt);
						n.rotate(Degreef.createFrom(10.0f), Vector3f.createFrom(0.0f, 1.0f, 0.0f));
					}
					else {
						ant.setBlocked(false);
						ant.setBlocker(null);
					}
					
					totalTime = 0.0f;
				}
				 game.updateVerticalPosition(ant.getMyName(), ant.getHeightOffset());
			 }
			 else if(ant.getState() == "ATTACK") {
				 if(ant.isBlocked() && ant.getBlocker() instanceof Player) {
					 ant.getSceneNode().lookAt(ant.getBlocker().getSceneNode());
					 
					 if(game.checkCollision(ant, ant.getBlocker())) {
						 if(timer > 1000.0f) {
							 Player pl = (Player)ant.getBlocker();
							 pl.setHealth(pl.getHealth() - 2.0f);
							 if(pl.getHealth() <= 0.0f) {
								 pl.setState("DEATH");
								 ant.setState("WALK");
							 }
							 System.out.println("Player Health: " + pl.getHealth());
							 timer = 0.0f;
						 }
					 }
					 else {
						 ant.setBlocker(null);
						 ant.setBlocked(false);
						 ant.setState("WALK");
					 }
				 }
				 else if(ant.isBlocked() && ant.getBlocker() instanceof PowerSource) {
					 ant.getSceneNode().lookAt(ant.getBlocker().getSceneNode());
					 
					 if(timer > 1000.0f) {
						 PowerSource ps = (PowerSource)ant.getBlocker();
						 ps.setHealth(ps.getHealth() - 2.0f);
						 if(ps.getHealth() <= 0.0f) {
							 ps.setState("DEATH");
						 }
						 else {
							 ps.setHurtFlag(true);
						 }
						 //System.out.println("PowerSource Health: " + ps.getHealth());
						 timer = 0.0f;
					 }
				 }
			 }
			 else if(ant.getState() == "DEATH") {
				 //nothing really happens here...
			 }
		 }
	}
}
