/*********************************************************************
 * BugTankController.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/14/2019
 ********************************************************************/
package a3;

import ray.rage.scene.*;
import ray.rage.scene.controllers.*;
import ray.rml.Angle;
import ray.rml.Degreef;
import ray.rml.Vector3f;

public class BugTankController extends AbstractController {
	
	private MyGame game;
	private BugTank bug;
	private float movAmt = 0.1f;
	private Angle rotAmt = Degreef.createFrom(0.0f);
	private float cycleTime = 2000.0f; // default cycle time (2 seconds)
	private float totalTime = 0.0f;
	private float timer = 0.0f;
	
	public BugTankController(MyGame g, BugTank b) {
		game = g;
		bug = b;
	}
	
	@Override
	protected void updateImpl(float elapsedTimeMillis) {
		 totalTime += elapsedTimeMillis;
		 timer += elapsedTimeMillis;

		 if (totalTime > cycleTime) {
			 
			 if(bug.getState() == "WALK") {
				 for(Node n : super.controlledNodesList) {
					 SceneNode psourceN = game.getEngine().getSceneManager().getSceneNode("powersourceNode");
					 n.lookAt(psourceN);
				 }
			 }
			 else if(bug.getState() == "ATTACK") {
				 for(Node n : super.controlledNodesList) {
					 
				 }
			 }
			 else if(bug.getState() == "DEATH") {
				 for(Node n : super.controlledNodesList) {
					 bug.setMarkDeath(true);
				 }
			 }
			 
			 totalTime = 0.0f;
		 }
		 
		 for(Node n : super.controlledNodesList) {
			 
			 if(bug.getState() == "WALK") {
				 n.moveForward(movAmt);
				 
				 if(bug.isBlocked()) {
					boolean blocked = game.checkCollision(bug, bug.getBlocker());
					
					if(blocked) {
						n.moveForward(-movAmt);
						n.rotate(Degreef.createFrom(-10.0f), Vector3f.createFrom(0.0f, 1.0f, 0.0f));
					}
					else {
						bug.setBlocked(false);
						bug.setBlocker(null);
					}
					
					totalTime = 0.0f;
				}
				 game.updateVerticalPosition(bug.getMyName(), 0.0f);
			 }
			 else if(bug.getState() == "ATTACK") {
				 if(bug.isBlocked() && bug.getBlocker() instanceof PowerSource) {
					 bug.getSceneNode().lookAt(bug.getBlocker().getSceneNode());
					 
					 if(timer > 1000.0f) {
						 PowerSource ps = (PowerSource)bug.getBlocker();
						 ps.setHealth(ps.getHealth() - 15.0f);
						 if(ps.getHealth() <= 0.0f) {
							 ps.setState("DEATH");
						 }
						 else {
							 ps.setHurtFlag(true);
						 }
						 //System.out.println("PowerSource Health: " + ps.getHealth());
						 timer = 0.0f;
					 }
				 }
			 }
			 else if(bug.getState() == "DEATH") {
				 //nothing really happens here...
			 }
		 }
	}
}
