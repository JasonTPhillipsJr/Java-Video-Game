/*********************************************************************
 * Player.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/2/2019
 ********************************************************************/
package a3;

import java.io.*;

import ray.rage.asset.texture.*;
import ray.rage.rendersystem.Renderable.*;
import ray.rage.rendersystem.states.RenderState;
import ray.rage.rendersystem.states.TextureState;
import ray.rage.scene.*;
import ray.rml.Degreef;

public class Player implements ICollidable {

	private SceneManager sm;
	private SkeletalEntity playerSE;
	private SceneNode playerN;
	private ICollidable blocker = null;
	private boolean blocked = false;
	private String myName;
	private String cur_State; //WALK, ATTACK, DEATH
	private boolean markedfordeath = false;
	private float health;
	private int bulletcount = 0;
	private float height_offset = 4.0f;
	private float x_offset = 2.0f,
			  	  y_offset = 5.0f,
			  	  z_offset = 2.0f;
	
	public Player(SceneManager sceneman, String name, String choice) throws IOException {
		sm = sceneman;
		myName = name;
		health = 100.0f;
		cur_State = "IDLE";
		
		if(choice == "Player1") {
			playerSE = sm.createSkeletalEntity(name, "Player1.rkm", "Player1.rks");
			Texture tex = sm.getTextureManager().getAssetByPath("Player.png");
			TextureState tstate = (TextureState)sm.getRenderSystem().createRenderState(RenderState.Type.TEXTURE);
			tstate.setTexture(tex);
			playerSE.setRenderState(tstate);
			
			playerSE.loadAnimation("WalkAnimation", "Player1Walk.rka");
			playerSE.loadAnimation("DeathAnimation", "Player1Death.rka");
		}
		else {
			playerSE = sm.createSkeletalEntity(name, "Player2.rkm", "Player2.rks");
			Texture tex = sm.getTextureManager().getAssetByPath("Player2.png");
			TextureState tstate = (TextureState)sm.getRenderSystem().createRenderState(RenderState.Type.TEXTURE);
			tstate.setTexture(tex);
			playerSE.setRenderState(tstate);
			
			playerSE.loadAnimation("WalkAnimation", "Player2Walk.rka");
			playerSE.loadAnimation("DeathAnimation", "Player2Death.rka");
		}
		
		
		playerN = sm.getRootSceneNode().createChildSceneNode(playerSE.getName() + "Node");
		playerN.attachObject(playerSE);
	}
	
	public SceneNode getSceneNode() { return playerN; }
	public SkeletalEntity getEntity() { return playerSE; }
	
	public void handleCollision(ICollidable o) {
		if(o instanceof Pillar ||
		   o instanceof PowerSource ||
		   o instanceof ArmorAnt ||
		   o instanceof BugTank) {
			this.setBlocker(o);
			blocked = true;
		}
		else if(o instanceof Bullet) {
			health -= 10.0f;
			if(health <= 0.0f) {
				//Player died. Change to Death State here.
				cur_State = "DEATH";
			}
		}
	}
	
	public float getOffsetX() { return x_offset; }
	public float getOffsetY() { return y_offset; }
	public float getOffsetZ() { return z_offset; }
	
	public boolean isBlocked() { return blocked; }
	public void setBlocked(boolean value) { blocked = value; }
	
	public ICollidable getBlocker() { return blocker; }
	public void setBlocker(ICollidable b) { blocker = b; }
	
	public float getHeightOffset() { return height_offset; }
	
	public void setHealth(float v) { health = v; }
	public float getHealth() { return health; }
	
	public void setBulletCount(int v) { bulletcount = v; }
	public int getBulletCount() { return bulletcount; }
	
	public String getMyName() { return myName; }
	
	public void setMarkDeath(boolean value) { markedfordeath = value; }
	public boolean isMarkedDeath() { return markedfordeath; }
	
	public void setState(String value) { cur_State = value; }
	public String getState() { return cur_State; }
}
