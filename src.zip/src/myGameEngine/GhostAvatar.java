/*********************************************************************
 * GhostAvatar.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 4/17/2019
 ********************************************************************/
 package myGameEngine;

import java.io.IOException;
import java.net.InetAddress;
import java.util.UUID;
import ray.networking.server.GameConnectionServer;
import ray.networking.server.IClientInfo;
import ray.rage.scene.Entity;
import ray.rage.scene.SceneNode;
import ray.rml.Vector3;

public class GhostAvatar 
{
	private UUID id;
	private SceneNode node;
	private Entity entity;
	private Vector3 pos;
	private String playerSelected;
	private String playerState;
	
	public GhostAvatar(UUID id, Vector3 position, String playerChoice, String playerState)
	{
		this.id = id;
		this.pos = position;
		this.playerSelected = playerChoice;
		this.playerState = playerState;
	}

	public Object getID() 
	{
		return id;
	}

	public void setNode(SceneNode ghostN) 
	{
		node = ghostN;
		// TODO Auto-generated method stub
	}

	public void setEntity(Entity ghostE) 
	{
		entity = ghostE;
		// TODO Auto-generated method stub	
	}
	
	public void setPos(Vector3 position)
	{
		//System.out.println("position");
		this.pos = position;
	}
	
	public Vector3 getPos()
	{
		return pos;
	}
	
	public String getPlayerChoice()
	{
		return playerSelected;
	}
	
	public String getPlayerState()
	{
		return playerState;
	}
	
	public void setPlayerState(String state)
	{
		playerState = state;
	}
	
	//Down here is where I need to put accessors and setters for id, node, entity, and position.
}
