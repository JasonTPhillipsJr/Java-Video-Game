/*********************************************************************
 * TurnOnPSAction.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 5/16/2019
 ********************************************************************/
package myGameEngine;

import a3.*;
import ray.input.action.AbstractInputAction;
import ray.rage.game.*;
import net.java.games.input.Event;

public class TurnOnPSAction extends AbstractInputAction {

	private MyGame game;
	
	public TurnOnPSAction(MyGame g) {
		game = g;
	}
	
	public void performAction(float time, Event event) {
		game.turnOnPowerSource();
	}
}