/*********************************************************************
 * ProtocolClient.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 4/17/2019
 ********************************************************************/
 package myGameEngine;

import java.util.Vector;

import javax.vecmath.Matrix3f;

import a3.MyGame;

import java.io.IOException;
import java.net.InetAddress;
import java.util.UUID;

import ray.networking.IGameConnection.ProtocolType;
import ray.networking.client.GameConnectionClient;
import ray.networking.server.GameConnectionServer;
import ray.networking.server.IClientInfo;
import ray.rml.Angle;
import ray.rml.Degreef;
import ray.rml.Matrix3;
import ray.rml.Vector3;
import ray.rml.Vector3f;

public class ProtocolClient extends GameConnectionClient
{
	private MyGame game;
	private UUID id;
	private Vector<GhostAvatar> ghostAvatars;
	private GhostAvatar avatar;
	private boolean done;
	private String playerSelected;
	private String playerState;
	
	public ProtocolClient(InetAddress remAddr, int remPort,
			ProtocolType pType, MyGame game) throws IOException
	{
		super(remAddr, remPort, pType);
		this.game = game;
		this.id = UUID.randomUUID();
		this.ghostAvatars = new Vector<GhostAvatar>();
		this.playerSelected = this.game.getCharacterSelect();
		this.playerState = this.game.getPlayerState();
	}
	
	@Override
	protected void processPacket(Object o)
	{
		String message = (String) o;
		String[] msgTokens = message.split(",");
		
		//System.out.println("Packet sent/recieved");
		if(msgTokens.length > 0)
		{
			if(msgTokens[0].compareTo("join") == 0)
			{
				//format: join, success or join, failure
				if(msgTokens[1].compareTo("success") == 0)
				{
					game.setIsConnected(true);
					sendCreateMessage(game.getPlayerPosition());
				}
				if(msgTokens[1].compareTo("failure") == 0)
				{
					game.setIsConnected(false);
				}
			}
			
			if(msgTokens[0].compareTo("redo") == 0)
			{
				System.out.println("reloaded");
				sendCreateMessage(game.getPlayerPosition());
			}
			
			if(msgTokens[0].compareTo("bye") == 0)
			{
				//formate bye, remoteId
				UUID ghostID = UUID.fromString(msgTokens[1]);
				removeGhostAvatar(ghostID);
			}
			
			if((msgTokens[0].compareTo("dsfr") ==0)||(msgTokens[0].compareTo("create") == 0))
			{
				
					//format: create, remoteID,x,y,z or dsfr, remoteid,x,y,z
					UUID ghostID = UUID.fromString(msgTokens[1]);
					Vector3 ghostPosition = Vector3f.createFrom(
							Float.parseFloat(msgTokens[2]),
							Float.parseFloat(msgTokens[3]),
							Float.parseFloat(msgTokens[4]));
					System.out.println("ghost made here");
					String playerChoice = msgTokens[5];
					String playerState = msgTokens[6];
					createGhostAvatar(ghostID, ghostPosition, playerChoice, playerState);//There was a catch clause here, keep this in mind in case of errors while testing.
			}
			
			if(msgTokens[0].compareTo("wsds") == 0)
			{
				if(game.getSet() == false)
				{
					try
					{
						sendPacket(new String("dsfr," + id.toString()));
					}
					catch(IOException e)
					{
						System.out.println("error in dsfr");
					}
				}
				else
				{
					//
				}
			}
			
			if(msgTokens[0].compareTo("wsds") == 0)
			{
				//rec. " wants"
				//Gotta Do
			}
			
			if(msgTokens[0].compareTo("move") == 0)
			{
				//UUID ghostID = UUID.fromString(msgTokens[1]);
				Vector3 ghostPosition = Vector3f.createFrom(
						Float.parseFloat(msgTokens[2]),
						Float.parseFloat(msgTokens[3]),
						Float.parseFloat(msgTokens[4]));
				//System.out.println("ghost pos updated");
				updateGhostPos(ghostPosition);
			}
			
			if(msgTokens[0].compareTo("rotate") == 0)
			{
				Float rotAmount = Float.parseFloat(msgTokens[2]);
				//System.out.println("client got ghost rotation angle");
				updateGhostRot(rotAmount);
			}
			
			if(msgTokens[0].compareTo("pState") == 0)
			{
				String ghostState = msgTokens[2];
				//System.out.println("client got the ghost state");
				updateGhostState(ghostState);
			}
			
			if(msgTokens[0].compareTo("BUG") == 0)
			{
				String name = msgTokens[2];
				Float health = Float.parseFloat(msgTokens[3]);
				String state = msgTokens[4];
				updateBugs(name,health,state);
				
			}
		}
	}
	
	public void sendBugInfo(String name, float health, String state)
	{
		try
		{
			String message = new String("BUG," + id.toString() + "," + name + "," + health + "," + state);
			sendPacket(message);
		}
		catch(IOException e)
		{
			System.out.println("Error when sending bug info");
		}
	}
	
	private void updateBugs(String name, Float health, String state) 
	{
		game.setEnemyInfo(name,health,state);
	}

	public void updateGhostRot(Float rotAmount)
	{
		game.rotateGhostAvatar(rotAmount);
		
	}
	
	public void updateGhostState(String state)
	{
		avatar.setPlayerState(state);
		game.updateGhostState(state);
		
	}

	public void removeGhostAvatar(UUID ghostID) 
	{
		//Gotta Do
	}

	public void createGhostAvatar(UUID ghostID, Vector3 ghostPosition, String playerChoice, String playerState) 
	{
	    avatar = new GhostAvatar(ghostID,ghostPosition, playerChoice, playerState);
		game.addGhostAvatarToGameWorld(avatar);
	}
	
	public void updateGhostPos(Vector3 ghostPosition)
	{
		avatar.setPos(ghostPosition);
		game.updateGhostPos(avatar);
	}

	public void sendJoinMessage()
	{
		try
		{
			sendPacket(new String("join," + id.toString()));
			System.out.println("Sent join message to server address");
		}
		catch (IOException e)
		{
			e.printStackTrace();
			System.out.println("nothing happened at send join message");
		}
	}
	
	public void sendCreateMessage(Vector3 pos)
	{
		//format: (create, localid,x,y,z)
		try
		{
			String message = new String("create," + id.toString());
			message += "," + pos.x() + "," + pos.y() + "," + pos.z() + "," + playerSelected + "," + playerState; // Added playerSelected variable to tell the other player what character model you chose.
			sendPacket(message);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void sendByeMessage()
	{
		try
		{
			String message = new String("bye");
			System.out.println("Sent message bye");
			sendPacket(message);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	public void sendDetailsForMessage(UUID remid, Vector3f pos)
	{
		//Gotta do
	}
	
	public void sendMoveMessage(Vector3 pos)
	{
		try
		{
			String message = new String("move," + id.toString());
			message += "," + pos.x() + "," + pos.y() + "," + pos.z();
			//System.out.println("sending move");
			sendPacket(message);
		}
		catch(IOException e)
		{
			System.out.println("error when sending move message");
		}
	}
	
	public UUID getID()
	{
		return id;
	}
	
	
	//Functions to look up ghost in table, update ghost position, and accessors as needed here.
	
	public void sendRotMessage(Float rot)
	{
		try 
		{
			String message = new String("rotate," + id.toString() + "," + rot);
			//System.out.println("sending rotate to server");
			
			sendPacket(message);
		}
		catch(IOException e)
		{
			System.out.println("error when sending rotate");
		}
	}
	
	public void sendStateMessage(String state)
	{
		try
		{
			String message = new String("pState," + id.toString() + "," + state);
			sendPacket(message);
		}
		catch(IOException e)
		{
			System.out.println("error when sending player state");
		}
	}

	public void sendcloseMessage() 
	{
		try
		{
			String message = new String("close");
			System.out.println("Sent message close");
			sendPacket(message);
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	

}
