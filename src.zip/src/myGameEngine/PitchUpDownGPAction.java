/*********************************************************************
 * PitchUpDownGPAction.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 3/17/2019
 ********************************************************************/
package myGameEngine;

import a3.*;
import ray.input.action.AbstractInputAction;
import ray.rage.game.*;
import net.java.games.input.Event;

public class PitchUpDownGPAction extends AbstractInputAction {

	private MyGame game;
	
	public PitchUpDownGPAction(MyGame g) {
		game = g;
	}
	
	public void performAction(float time, Event event) {
		if(event.getValue() < -0.1) {
			game.pitchUp("player");
		}
		else if(event.getValue() > 0.1) {
			game.pitchDown("player");
		}
	}
}
