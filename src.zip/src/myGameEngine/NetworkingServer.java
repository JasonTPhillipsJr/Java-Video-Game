/*********************************************************************
 * NetworkingServer.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 4/17/2019
 ********************************************************************/
 package myGameEngine;

import java.io.IOException;
import ray.networking.IGameConnection.ProtocolType;



public class NetworkingServer 
{
	private GameServerUDP thisUDPServer;
	//private NPCcontroller npcCtrl;		//This is the NPC controller.
	private long startTime;			//Start time.
	private long lastUpdateTime;		//End time.
	//private long FrameStartTime;
	
	
	public NetworkingServer(int serverPort, String protocol)
	{
		startTime = System.nanoTime();
		lastUpdateTime = startTime;
		//npcCtrl = new NPCcontroller();	//Create a new instance of an NPC controller.
		try
		{
			thisUDPServer = new GameServerUDP(serverPort);
			System.out.println("Server is up and running");
			System.out.println("server port being used is: " + serverPort);
		}
		catch(IOException e)
		{
			System.out.println("didn't work");
			e.printStackTrace();
		}
		
		//npcCtrl.setupNPCs();			//Setting up NPCs Stuff to Do
		//npcLoop();						//Runs below function
	}
	
	
	public void npcLoop()
	{
		while(true)
		{
			long frameStartTime = System.nanoTime();
			float elapMilSecs = (frameStartTime-lastUpdateTime)/(100000.0f);
			if(elapMilSecs>=50.0f)		//This seems to run below code every few ms. Probably to reduce processing power.
			{
				
				lastUpdateTime = frameStartTime;
				//npcCtrl.updateNPCs();
				thisUDPServer.sendNPCinfo();
			}
			Thread.yield();
			
		}
	}
	public static void main(String[] args)
	{
		
		if(args.length>1)
		{
			NetworkingServer app = 
					new NetworkingServer(Integer.parseInt(args[0]),args[1]);
		}

		else
			System.out.println("input a server port and a protocol type (UDP)");
	}
}
