/*********************************************************************
 * RotateLeftRightGPAction.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 3/17/2019
 ********************************************************************/
package myGameEngine;

import a3.*;
import ray.input.action.AbstractInputAction;
import ray.rage.game.*;
import net.java.games.input.Event;

public class RotateLeftRightGPAction extends AbstractInputAction {

	private MyGame game;
	
	public RotateLeftRightGPAction(MyGame g) {
		game = g;
	}
	
	public void performAction(float time, Event event) {
		if(event.getValue() < -0.1) {
			game.rotateLeft("player");
		}
		else if(event.getValue() > 0.1) {
			game.rotateRight("player");
		}
	}
}
