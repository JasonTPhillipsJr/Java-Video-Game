/*********************************************************************
 * MoveBackForthGPAction.java
 * Authors: Jason Phillips & Andrew Wright
 * Created: 3/17/2019
 ********************************************************************/
package myGameEngine;

import a3.*;
import ray.input.action.AbstractInputAction;
import ray.rage.game.*;
import ray.rage.scene.SkeletalEntity;
import net.java.games.input.Event;

public class MoveBackForthGPAction extends AbstractInputAction {

	private MyGame game;
	private Player player;
	
	public MoveBackForthGPAction(MyGame g, Player p) {
		game = g;
		player = p;
	}
	
	public void performAction(float time, Event event) {
		if(event.getValue() < -0.1) {
			player.setState("WALK");
			game.doTheWalk((SkeletalEntity)game.getEngine().getSceneManager().getEntity("player"));
			game.moveForward("player", player);
			player.setState("IDLE");
			game.doTheIdle((SkeletalEntity)game.getEngine().getSceneManager().getEntity("player"));
		}
		else if(event.getValue() > 0.1) {
			player.setState("WALK");
			game.doTheWalk((SkeletalEntity)game.getEngine().getSceneManager().getEntity("player"));
			game.moveBackward("player", player);
			player.setState("IDLE");
			game.doTheIdle((SkeletalEntity)game.getEngine().getSceneManager().getEntity("player"));
		}
		
		game.updateVerticalPosition("player", player.getHeightOffset());
	}
}
